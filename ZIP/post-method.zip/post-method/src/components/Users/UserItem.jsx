export const UserItem = ({ user }) => (
  <div className="box">
    <p>{user.name}</p>
    <p>{user.price}</p>
  </div>
);
