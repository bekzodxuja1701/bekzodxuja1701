import { useDispatch, useSelector } from "react-redux";
import "./App.css";
import Counter from "./components/Counter";
import UserProfile from "./components/UserProfile";
import * as counterAction from "./store/actions";

function App() {
  const isAuth = useSelector((state) => state.auth.isAuth);
  const dispatch = useDispatch();
  const logins = () => dispatch(counterAction.login());
  return (
    <>
      {isAuth && <UserProfile />}
      {!isAuth && <button onClick={logins}>login</button>}
      <Counter />
    </>
  );
}

export default App;
