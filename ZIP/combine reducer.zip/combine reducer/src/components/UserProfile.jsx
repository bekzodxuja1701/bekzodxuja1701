import React from "react";
import { useDispatch } from "react-redux";
import * as counterAction from "../store/actions";
const UserProfile = () => {
  const dispatch = useDispatch();
  const logout = () => dispatch(counterAction.logout());

  return (
    <div>
      <h1>Welcome My profile</h1>
      <button onClick={logout}>logout</button>
    </div>
  );
};

export default UserProfile;
