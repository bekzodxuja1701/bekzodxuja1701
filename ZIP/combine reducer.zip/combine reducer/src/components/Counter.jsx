import React from "react";
import { useDispatch, useSelector } from "react-redux";
import * as counterAction from "../store/actions";

const Counter = () => {
  // const count = useSelector((state) => state.count);
  // const showCounter = useSelector((state) => state.showCounter);
  const { count, showCounter } = useSelector((state) => state.counter);

  const dispatch = useDispatch();

  const decrements = () => dispatch(counterAction.decrement());
  const increments = () => dispatch(counterAction.increment());
  const toggle = () => dispatch(counterAction.toggle());

  return (
    <div>
      {showCounter && (
        <div>
          <h1>{count}</h1>
          <button onClick={decrements}>DECREMENT</button>
          <button onClick={increments}>INCREMENT</button>
        </div>
      )}
      <div>
        <button onClick={toggle}>show/hide counter</button>
      </div>
    </div>
  );
};

export default Counter;
