export const DEC = "DEC";
export const INC = "INC";
export const TOGGLE = "TOGGLE";
export const LOGIN = "LOGIN";
export const LOGOUT = "LOGOUT";
