import { combineReducers, createStore } from "redux";
import { reducerCounter } from "./reducers/counterReducers";
import { reducerAuth } from "./reducers/authReducers";

const reducers = combineReducers({
  counter: reducerCounter,
  auth: reducerAuth,
});
const store = createStore(reducers);

export default store;
