const initialAuthValues = { isAuth: false };

export const reducerAuth = (state = initialAuthValues, action) => {
  switch (action.type) {
    case "LOGIN": {
      console.log("auth reducer working ... ");
      return {
        ...state,
        isAuth: true,
      };
    }
    case "LOGOUT": {
      return {
        ...state,
        isAuth: false,
      };
    }
    default: {
      return state;
    }
  }
};
