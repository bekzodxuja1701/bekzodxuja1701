const initialCounterValues = { count: 1, showCounter: true };
export const reducerCounter = (state = initialCounterValues, action) => {
  switch (action.type) {
    case "INC": {
      return {
        ...state,
        count: state.count + 1,
      };
    }
    case "DEC": {
      return {
        ...state,
        count: state.count - 1,
      };
    }
    case "TOGGLE": {
      return {
        ...state,
        showCounter: !state.showCounter,
      };
    }
    // case "LOGIN": {
    //   console.log("counter reducer working ... ");
    // }
    default: {
      return state;
    }
  }
};
