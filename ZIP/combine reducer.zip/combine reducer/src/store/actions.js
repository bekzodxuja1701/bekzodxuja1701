import { DEC, INC, LOGIN, LOGOUT, TOGGLE } from "./action-tpes";

export const increment = () => ({ type: INC });
export const decrement = () => ({ type: DEC });
export const toggle = () => ({ type: TOGGLE });
export const login = () => ({ type: LOGIN });
export const logout = () => ({ type: LOGOUT });
