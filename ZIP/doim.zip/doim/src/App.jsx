import Home from "./pages/home/Home";
import "./App.css";
const App = () => {
  return <Home />;
};

export default App;
