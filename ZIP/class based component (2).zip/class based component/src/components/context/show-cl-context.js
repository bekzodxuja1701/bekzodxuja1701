import { createContext } from "react";

const ShowClContext = createContext();

export default ShowClContext;
