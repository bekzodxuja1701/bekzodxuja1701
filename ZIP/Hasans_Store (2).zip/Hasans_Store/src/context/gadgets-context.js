import React from "react";

const GadgetsCtx = React.createContext();

export default GadgetsCtx;
