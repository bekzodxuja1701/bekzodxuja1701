import React from "react";

const RoutesContext = React.createContext();

export default RoutesContext;
