import React from "react";
import Orders from "../../components/Orders/Orders";

function Cart() {
  return <Orders />;
}

export default Cart;
