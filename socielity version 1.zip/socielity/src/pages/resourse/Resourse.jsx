export const Resourse = () => {
  return <div>Resourse</div>;
};
