export const Hero = () => {
  return <div>Hero</div>;
};
