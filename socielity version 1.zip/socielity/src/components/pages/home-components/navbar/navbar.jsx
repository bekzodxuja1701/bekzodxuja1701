export const Navbar = () => {
  return <div>navbar</div>;
};
