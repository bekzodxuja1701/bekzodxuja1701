export const Partners = () => {
  return <div>Partners</div>;
};
