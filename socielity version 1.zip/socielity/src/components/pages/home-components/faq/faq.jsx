export const Faq = () => {
  return <div>faq</div>;
};
