export const Footer = () => {
  return <div>footer</div>;
};
