export const Platform = () => {
  return <div>platform</div>;
};
