export const Know = () => {
  return <div>know</div>;
};
