export const Trusted = () => {
  return <div>Trusted</div>;
};
