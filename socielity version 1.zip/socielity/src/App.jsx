import { Home } from "./pages";

export const App = () => {
  return (
    <div className="container">
      <Home />
    </div>
  );
};
